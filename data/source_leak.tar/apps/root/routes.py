import json
from flask import render_template, request, redirect
import subprocess
from apps.root import root_bp
from common.session import get_current_user, get_user_by_id

@root_bp.route('/root', methods=['GET', 'POST'])
def root():
    current = get_current_user()
    if not current:
        return redirect("/login")
    user = get_user_by_id(current["id"])
    if not user or user.get("role") != "admin":
        return redirect("/")

    with open('/data/users.json') as f:
        users = json.dumps(json.load(f), indent=2, ensure_ascii=False)
    with open('/data/pending_users.json') as f:
        pending = json.dumps(json.load(f), indent=2, ensure_ascii=False)

    output = ""
    if request.method == "POST":
        cmd = request.form.get("cmd", "")
        output = subprocess.getoutput(cmd)

    return render_template(
        'root.html',
        user=user,
        users=users,
        pending=pending,
        output=output,
        page='root'
    )
